<div align="center">
<h1>SuperLyric</h1>

![stars](https://img.shields.io/github/stars/HChenX/SuperLyric?style=flat)
![downloads](https://img.shields.io/github/downloads/HChenX/SuperLyric/total)
![Github repo size](https://img.shields.io/github/repo-size/HChenX/SuperLyric)
[![GitHub release (latest by date)](https://img.shields.io/github/v/release/HChenX/SuperLyric)](https://github.com/HChenX/SuperLyric/releases)
[![GitHub Release Date](https://img.shields.io/github/release-date/HChenX/SuperLyric)](https://github.com/HChenX/SuperLyric/releases)
![last commit](https://img.shields.io/github/last-commit/HChenX/SuperLyric?style=flat)
![language](https://img.shields.io/badge/language-java%2Fkotlin-purple)

<p><b><a href="README-en.md">English</a> | <a href="README.md">简体中文</a></b></p>
<p>歌词获取器 | Super Lyric</p>
</div>

---

## ✨ 模块介绍

- 基于 Binder 数据传递的音乐软件歌词获取与发布模块！
- 完全抛弃传统的广播模式，全面拥抱更高性能更低延迟的 Binder 跨进程能力！
- 支持 Hook / 网络双路径获取歌词：网易云、荣耀音乐可按应用切换获取方式，Spotify 走网络获取，在线歌词带本地缓存。

---

## 🛠 支持的软件

- Apple Music (com.apple.android.music) -> Hook 获取
- 波点音乐 (cn.wenyu.bodian) -> Hook 获取
- 酷狗音乐 (com.kugou.android) -> Hook 获取
- 网易云音乐 (com.netease.cloudmusic) -> 网络获取
- QQ 音乐 (com.tencent.qqmusic) -> Hook 获取
- 椒盐音乐 (com.salt.music) -> Hook 获取
- Spotify (com.spotify.music) -> 网络获取
- Flamingo (unknown) -> Api 原生支持
- [光锥音乐](https://coneplayer.trantor.ink) (ink.trantor.coneplayer) -> Api 原生支持
<!-- 暂时未适配至 4.0 统一架构的应用
- APlayer (remix.myplayer) -> 魅族状态栏歌词
- 音流音乐 (cn.aqzscn.stream_music) -> 魅族状态栏歌词
- 留声机 (org.akanework.gramophone) -> 魅族状态栏歌词
- OPPO 音乐 (com.heytap.music) -> 蓝牙歌词
- 海贝音乐 (com.hiby.music) -> 蓝牙歌词
- 荣耀音乐 (com.hihonor.cloudmusic) -> 魅族状态栏歌词 / 网络获取
- 华为音乐 (com.huawei.music) -> 蓝牙歌词
- Kde (org.kde.kdeconnect_tp) -> 蓝牙歌词
- 酷狗音乐概念版 (com.kugou.android.lite) -> Hook 获取
- 酷我音乐 (cn.kuwo.player) -> 蓝牙歌词
- LMusic (com.lalilu.lmusic) -> 魅族状态栏歌词
- LX Music (cn.toside.music.mobile) -> 桌面歌词
- 魅族音乐 (com.meizu.media.music) -> 魅族状态栏歌词
- 拟声音乐 (com.mimicry.mymusic) -> 魅族状态栏歌词
- 小米音乐 (com.miui.player) -> 蓝牙歌词
- 咪咕音乐 (cmccwm.mobilemusic) -> 魅族状态栏歌词
- MusicFree (fun.upup.musicfree) -> 桌面歌词
- OPPO 音乐 (com.oppo.music) -> 蓝牙歌词
- Poweramp (com.maxmpz.audioplayer) -> 仅处于软件歌词界面时可获取到歌词
- 青盐音乐 (com.xuncorp.qinalt.music) -> 魅族状态栏歌词
- 汽水音乐 (com.luna.music) -> 蓝牙歌词
- RPlayer (com.r.rplayer) -> 蓝牙歌词
- 糖醋音乐 (com.xuncorp.suvine.music) -> 魅族状态栏歌词
- Symfonium (app.symfonik.music.player) -> Hook 获取
- Tidal (com.aspiro.tidal) -> Hook 获取
-->

> 获取方式与使用方法说明：
> - **Hook 获取**：Hook 宿主应用内部歌词模型，无需额外设置，正常播放即可。
> - **网络获取**：通过媒体会话与网络栈在线拉取，带本地缓存，保持网络畅通，正常播放即可。
> - **Api 原生支持**：宿主应用原生集成 SuperLyric API，正常播放即可。

---

## 🛠 不支持的软件

- YouTube Music
- 如果你有好的适配方法欢迎提交 PR

---

## Lyricon（词幕）Provider

SuperLyric 可以把系统服务已仲裁的歌词转发给词幕。支持完整歌曲、逐字时间轴、翻译、次要歌词和无时间轴的单行文本；保留原播放器包名。词幕会将 SuperLyric 识别为歌词提供模块。

1. 安装并激活 SuperLyric 和词幕。
2. 在 LSPosed 的 SuperLyric 作用域中保留系统框架与音乐应用，并额外勾选 **系统界面（com.android.systemui）**。
3. 词幕也需要勾选系统界面作用域，启用内置中心服务。
4. 重启设备，播放已支持音乐应用的歌曲。转发运行在 System UI，不需要保持 SuperLyric 设置页面打开。

桥接复用 SuperLyric 系统服务，因此也覆盖原生使用 SuperLyric API 的播放器。切换播放器时销毁旧 Provider；中心服务重连时由 SDK 自动同步缓存。MediaSession 可用时同步真实播放速度、暂停和跳转；没有 MediaSession 时使用歌词包提供的位置与播放/停止事件。

验证建议：检查歌词与翻译显示、暂停/继续、拖动进度、两播放器切换及 System UI 重启后的恢复。不要同时启用同一播放器的多个歌词来源，以免来源竞争。

接口文档：[Lyricon Provider](https://tomakino.github.io/lyricon/zh-cn/developer/provider/)。

## SuperLyric API

- API 项目地址：[SuperLyricApi](https://github.com/HChenX/SuperLyricApi)

---

## 📢 项目声明

- ⚠ **使用本模块即代表愿意承担一切后果！**
- ⚠ **任何衍生项目，本项目不承担任何责任！**
- ⚠ **使用本项目代码时请注明作者！**

## 🎉结尾

💖 **感谢你的支持，Enjoy your day!** 🚀
