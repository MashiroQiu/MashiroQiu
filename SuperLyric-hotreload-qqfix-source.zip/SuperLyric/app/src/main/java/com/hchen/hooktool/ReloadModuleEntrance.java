/*
 * This file is part of HookTool.
 *
 * HookTool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * HookTool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with HookTool. If not, see <https://www.gnu.org/licenses/lgpl-2.1>.
 *
 * Copyright (C) 2024–2026 HChenX
 */
package com.hchen.hooktool;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hchen.hooktool.core.CoreTool;
import com.hchen.hooktool.hook.AbsHook;
import com.hchen.hooktool.hook.HookRegistry;
import com.hchen.hooktool.log.AndroidLog;
import com.hchen.hooktool.log.XposedLog;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/**
 * Xposed 模块的启动入口基类，继承自 {@link XposedModule}。
 * <p>
 * 该类作为框架回调与业务逻辑之间的桥梁，负责管理从模块加载到 Application 创建
 * 的完整生命周期流程。子类必须实现 {@link #initModuleConfig()} 完成配置初始化，
 * 可选择性覆写 {@link #ignorePackages()} 排除不需要处理的目标包。
 * <p>
 * 当目标应用的 {@link Application#attach(Context)} 被调用时，框架会自动
 * 触发 {@link #handleApplicationCreated(Context)} 回调。
 * <p>
 * 从 API 102 开始支持热更新（Hot Reload）：
 * <ul>
 *   <li>{@link #handleHotReloading(Bundle)} — 热更新前在旧代码中执行，返回需保存的状态数据</li>
 *   <li>{@link #handleHotReloadingFailed(Throwable)} — 热更新准备阶段发生异常时的回调</li>
 *   <li>{@link #isHotReloadingAllowed(String)} — 按目标包名决定是否允许热更新（可覆写）</li>
 *   <li>{@link #handleHotReloaded(HotReloadedParam, ClassLoader)} — 热更新完成后在新代码中执行，
 *       携带恢复的 ClassLoader，自动解除旧 Hook 并重新分发状态</li>
 * </ul>
 *
 * @author 焕晨HChen
 * @see AbsModule
 * @see ModuleConfig
 * @see XposedModuleInterface
 */
/** Derived from HookTool 3.2.2 ModuleEntrance; preserves the LGPL 2.1-or-later license above.
 * Local change: retain the stable service hook through API 102 atomic replacement.
 * Source: https://github.com/HChenX/HookTool/blob/master/tool/src/main/java/com/hchen/hooktool/ModuleEntrance.java
 */
public abstract class ReloadModuleEntrance extends XposedModule {
    // 标记当前包是否应被跳过处理
    private volatile boolean shouldSkip = false;
    private volatile String processName = "";
    // 当前正在处理的目标包名，供热重载允许/拒绝策略使用
    private volatile String currentPackageName = "";

    /**
     * 初始化模块配置的抽象方法。
     * <p>
     * 子类必须实现此方法，在其中通过 {@link ModuleConfig} 的静态方法完成
     * 日志标签、日志等级、SharedPreferences 名称等基本参数的设置。
     * 此方法在 {@link #onModuleLoaded(ModuleLoadedParam)} 回调中最先被调用。
     */
    public abstract void initModuleConfig();

    /**
     * 返回需要跳过处理的目标包名列表。
     * <p>
     * 当目标应用的包名与列表中任一项匹配时，后续的
     * {@link #handlePackageLoaded(PackageLoadedParam)}、
     * {@link #handlePackageReady(PackageReadyParam)} 以及
     * {@link #handleApplicationCreated(Context)} 回调将被自动跳过。
     *
     * @return 需要忽略的包名数组，默认返回空数组表示不跳过任何包
     */
    @NonNull
    public String[] ignorePackages() {
        return new String[]{};
    }

    /**
     * 模块加载完成时的回调。
     * <p>
     * Xposed 框架完成模块加载后触发。子类可覆写此方法执行模块级别的初始化操作，
     * 例如注册全局 Hook 或初始化共享资源。
     *
     * @param param 模块加载参数，包含框架相关信息
     */
    public void handleModuleLoaded(@NonNull ModuleLoadedParam param) {
    }

    /**
     * 目标应用包加载时的回调。
     * <p>
     * 当目标应用的包被框架加载时触发。子类可覆写此方法在包加载阶段
     * 提前进行 Hook 准备。
     *
     * @param param 包加载参数，包含目标包的相关信息
     */
    public void handlePackageLoaded(@NonNull PackageLoadedParam param) {
    }

    /**
     * 目标应用包资源就绪时的回调。
     * <p>
     * 当目标应用包的资源完成加载并就绪后触发。子类可覆写此方法在
     * 包就绪阶段执行需要完整包资源的 Hook 操作。
     *
     * @param param 包就绪参数，包含目标包的相关信息
     */
    public void handlePackageReady(@NonNull PackageReadyParam param) {
    }

    /**
     * 目标应用 Application 创建时的回调。
     * <p>
     * 当目标应用的 {@link Application#attach(Context)} 被调用时触发，
     * 此时应用 {@link Context} 已可用。子类可覆写此方法执行依赖应用上下文的 Hook 逻辑。
     *
     * @param context 目标应用的上下文对象
     */
    public void handleApplicationCreated(@NonNull Context context) {
    }

    /**
     * 系统服务器启动时的回调。
     * <p>
     * 当 Android 系统服务器进程启动时触发。子类可覆写此方法执行针对系统服务的 Hook 操作。
     *
     * @param param 系统服务器启动参数
     */
    public void handleSystemServerStarting(@NonNull SystemServerStartingParam param) {
    }

    /**
     * 模块即将被热更新时触发的回调（在旧代码中执行）。
     * <p>
     * 此回调在热更新触发时于旧模块代码中运行，子类应覆写此方法返回需要
     * 在热更新后恢复的状态键值对。返回的 {@link Map} 会被顶层
     * {@link #onHotReloading(HotReloadingParam)} 合并到全局快照中（与
     * {@link HookRegistry#reloading(Bundle)} 收集的钩子级状态一并合并），
     * 并通过 {@code param.setSavedInstanceState(merged)} 持久化。
     * <p>
     * 注意：该方法不再直接控制是否允许热更新——允许/拒绝逻辑统一由
     * {@code onHotReloading} 的顶层实现管理，可通过覆写
     * {@link #isHotReloadingAllowed(String)} 按目标包名控制。子类仅需关心状态数据的保存。
     *
     * @param extras 热更新触发的附加数据 {@link Bundle}，可能为 {@code null}
     *               （当框架未传递额外数据时）
     * @return 模块级状态键值对的 {@link Map}；默认返回空 {@link HashMap}，
     * 表示无需保存任何状态
     * @see #onHotReloading(HotReloadingParam)
     * @see #handleHotReloaded(HotReloadedParam, ClassLoader)
     */
    @NonNull
    public Map<String, Object> handleHotReloading(@Nullable Bundle extras) {
        return new HashMap<>();
    }

    /**
     * 热更新准备阶段发生异常时的回调。
     * <p>
     * 当 {@link #handleHotReloading(Bundle)} 或其内部钩子的状态收集过程
     * 抛出异常时触发。子类可覆写此方法执行资源清理或异常记录。
     * <p>
     * 注意：此回调执行完毕后，异常会通过 {@link CoreTool#throwIt(Throwable)}
     * 继续向上传播，最终 {@code onHotReloading} 返回 {@code false} 拒绝热更新。
     *
     * @param throwable 在热更新准备阶段被捕获的异常实例，不为 {@code null}
     * @see #handleHotReloading(Bundle)
     */
    public void handleHotReloadingFailed(Throwable throwable) {
    }

    /**
     * 判断当前模块是否允许目标应用进行热重载。
     * <p>
     * 默认返回 {@code true}（允许全部）。子类可覆写此方法，对需要阻止热重载的
     * 目标包名返回 {@code false}。当返回 {@code false} 时，顶层
     * {@link #onHotReloading(HotReloadingParam)} 会直接返回 {@code false} 拒绝热重载，
     * 不做任何状态保存与注册表清理（准备阶段无副作用）。
     * <p>
     * 注意：{@code packageName} 在 {@link #onPackageLoaded(PackageLoadedParam)} 阶段记录，
     * 因此仅在处理过目标包的进程中携带实际包名；在 SystemServer 等未触发
     * {@code onPackageLoaded} 的进程下可能为空字符串，覆写实现需对此容错。
     * 该字段由框架回调线程写入（通常为同一 Binder 线程），本方法不保证跨线程
     * 强同步可见性，覆写实现不应依赖其严格的最新值。
     *
     * @param packageName 目标被 Hook 应用的包名（在 onPackageLoaded 阶段记录，
     *                    SystemServer 等进程下可能为空字符串）
     * @return {@code true} 允许热重载；{@code false} 拒绝热重载
     * @see #onHotReloading(HotReloadingParam)
     */
    public boolean isHotReloadingAllowed(@NonNull String packageName) {
        return true;
    }

    /**
     * 模块已完成热更新时触发的回调（在新代码中执行）。
     * <p>
     * 此回调在热更新完成后于新模块代码中运行，此时已从旧代码保存的状态中
     * 恢复了宿主应用的 {@link ClassLoader}（框架已回写
     * {@link ModuleData#setClassLoader(ClassLoader)}，本方法内可直接使用默认类加载 API）。
     * 子类可覆写此方法执行重新挂钩或特定的初始化操作。
     * <p>
     * 旧 Hook 句柄的解除由 {@code onHotReloaded} 的 {@code finally} 块统一处理，
     * 子类无需手动解除。
     *
     * @param param       热更新完成参数，包含旧 Hook 句柄、保存的状态等信息，不为 {@code null}
     * @param classLoader 从旧代码保存的状态中恢复的宿主应用 ClassLoader，不为 {@code null}
     * @see #handleHotReloading(Bundle)
     * @see ModuleData#MODULE_HOST_CLASSLOADER
     */
    public void handleHotReloaded(@NonNull HotReloadedParam param, @NonNull ClassLoader classLoader) {
    }

    // ------------------------- Inner -----------------------------

    /**
     * 框架回调入口：模块加载完成。初始化 Xposed 环境与包装器、模块配置后分发业务回调。
     */
    @Override
    public final void onModuleLoaded(@NonNull ModuleLoadedParam param) {
        processName = param.getProcessName();
        ModuleData.setWrapper(this);

        initModuleConfig();
        handleModuleLoaded(param);
    }

    /**
     * 框架回调入口：目标应用包加载完成。按忽略列表过滤后记录目标包名并分发业务回调。
     */
    @Override
    public final void onPackageLoaded(@NonNull PackageLoadedParam param) {
        String[] ignored = ignorePackages();
        if (ignored.length > 0) {
            shouldSkip = Arrays.stream(ignored).anyMatch(
                p -> TextUtils.equals(p, param.getPackageName())
            );
        } else {
            shouldSkip = false;
        }

        if (shouldSkip) {
            return;
        }

        currentPackageName = param.getPackageName();
        handlePackageLoaded(param);
    }

    /**
     * 框架回调入口：目标应用包资源就绪。挂接 Application.attach 钩子后分发业务回调。
     */
    @Override
    public final void onPackageReady(@NonNull PackageReadyParam param) {
        if (shouldSkip) {
            return;
        }

        hookApplication(param);
        handlePackageReady(param);
    }

    /**
     * 框架回调入口：系统服务进程启动。直接分发业务回调。
     */
    @Override
    public final void onSystemServerStarting(@NonNull SystemServerStartingParam param) {
        handleSystemServerStarting(param);
    }

    /**
     * 框架回调入口：热更新准备阶段（旧代码执行）。收集状态并提交，允许/拒绝由
     * {@link #isHotReloadingAllowed(String)} 决定；状态保存成功后才清空注册表。
     */
    @Override
    public final boolean onHotReloading(@NonNull HotReloadingParam param) {
        try {
            // 允许/拒绝策略由子类覆写 isHotReloadingAllowed 控制；拒绝时直接返回，不做任何状态变更。
            if (!isHotReloadingAllowed(currentPackageName)) {
                return false;
            }

            // 在收集/清空注册表之前先取出 ClassLoader，失败则提前拒绝且注册表不受影响。
            ClassLoader classLoader = ModuleData.getClassLoader();

            Map<String, Object> merged = new HashMap<>();
            Map<String, Object> moduleState = handleHotReloading(param.getExtras());
            Map<String, Object> hookState = HookRegistry.reloading(param.getExtras()); // 不再内部清空注册表

            // 跨来源键冲突检测：hook 级状态后合并，同键时覆盖模块级状态并记录告警。
            for (String key : hookState.keySet()) {
                if (moduleState.containsKey(key)) {
                    AndroidLog.logW("ReloadModuleEntrance",
                        "Hot reload state key collision, hook state overrides module state: " + key);
                }
            }
            merged.putAll(moduleState);
            merged.putAll(hookState);
            // 框架保留键最后写入，优先级最高。
            merged.put(ModuleData.MODULE_HOST_CLASSLOADER, classLoader);

            param.setSavedInstanceState(merged);
            // 仅在状态保存成功后清空，热更新被拒绝时旧 hook 注册信息得以保留。
            // 已知限制：若框架在 setSavedInstanceState 后的重载操作失败（旧代码继续运行），
            // 注册表已清空而旧 hook 仍活跃且失联，二次热更新会丢失 hook 级状态。
            HookRegistry.clear();
            return true;
        } catch (Throwable throwable) {
            try {
                handleHotReloadingFailed(throwable);
            } catch (Throwable failedError) {
                XposedLog.logW("ReloadModuleEntrance",
                    "handleHotReloadingFailed() threw an exception, ignored to preserve the original exception.",
                    failedError);
            }
            CoreTool.throwIt(throwable);
            return false;
        }
    }

    /**
     * 框架回调入口：热更新完成（新代码执行）。恢复 ClassLoader 与配置，先解除旧 Hook
     * 再分发状态恢复，finally 幂等兜底解除。
     */
    @Override
    public final void onHotReloaded(@NonNull HotReloadedParam param) {
        List<HookHandle> oldHandles = param.getOldHookHandles(); // 预取，供先解除与 finally 兜底复用
        try {
            processName = param.getProcessName();
            ModuleData.setWrapper(this);

            initModuleConfig();

            ClassLoader classLoader = null;
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) param.getSavedInstanceState();
            if (map != null) {
                Object cl = map.get(ModuleData.MODULE_HOST_CLASSLOADER);
                if (cl instanceof ClassLoader) {
                    classLoader = (ClassLoader) cl;
                }
            }
            // 带上下文消息的校验，缺键/类型不匹配时给出可诊断提示，而非裸 NPE。
            Objects.requireNonNull(classLoader,
                "Hot update status missing or key mismatch: " + ModuleData.MODULE_HOST_CLASSLOADER);

            // 回写默认 ClassLoader，使 handleHotReloaded 及后续 CoreTool 默认类加载 API 可用。
            ModuleData.setClassLoader(classLoader);

            // Keep the stable service dispatcher until the new generation atomically replaces
            // its API 102 hook ID. Other hooks are removed before normal initialization.
            for (HookHandle old : oldHandles) {
                if (!"superlyric.service.endpoint".equals(old.getId())) old.unhook();
            }

            handleHotReloaded(param, classLoader);
            HookRegistry.reloaded(param);
        } finally {
            // 任何路径都确保旧 Hook 被解除。
            unhookAll(oldHandles);
        }
    }

    /**
     * 批量解除旧 Hook 句柄。{@link HookHandle#unhook()} 幂等，重复调用无害。
     *
     * @param handles 待解除的 Hook 句柄列表
     */
    private static void unhookAll(@NonNull List<HookHandle> handles) {
        for (HookHandle handle : handles) {
            handle.unhook();
        }
    }

    private volatile HookHandle handle;

    private void hookApplication(@NonNull PackageLoadedParam param) {
        if (param.isFirstPackage()) {
            // A first package also owns Application.attach in :QQPlayerService and other
            // named subprocesses. Its package name is not the full process name.
            if (ProcessPackages.belongsTo(param.getPackageName(), processName)) {
                if (handle != null) {
                    handle.unhook();
                    handle = null;
                }

                try {
                    handle = CoreTool.hookMethod(
                        Application.class,
                        "attach",
                        Context.class,
                        new AbsHook() {
                            @Override
                            public void before() {
                                Context context = (Context) getArg(0);
                                Objects.requireNonNull(context, "Application.attach context must not be null.");
                                handleApplicationCreated(context);
                            }
                        }
                    );
                } catch (Throwable e) {
                    AndroidLog.logW("ReloadModuleEntrance", "Failed to hook Application.attach()", e);
                }
            }
        }
    }
}
