/*
 * This file is part of SuperLyric.
 *
 * SuperLyric is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2025-2026 HChenX
 */
package com.hchen.superlyric;

import static com.hchen.hooktool.ModuleConfig.LOG_D;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.app.AppComponentFactory;
import android.os.Bundle;
import com.hchen.superlyric.core.SuperLyricProxy;
import com.hchen.superlyric.lyricon.LyriconBridge;
import com.hchen.superlyric.publisher.UnifiedLyricProvider;
import com.hchen.superlyric.reload.ReloadResources;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hchen.dexkitcache.DexkitCache;
import com.hchen.hooktool.AbsModule;
import com.hchen.hooktool.ModuleConfig;
import com.hchen.hooktool.ModuleData;
import com.hchen.hooktool.ReloadModuleEntrance;
import com.hchen.hooktool.log.AndroidLog;
import com.hchen.hooktool.utils.PrefsTool;
import com.hchen.processor.HookMaps;
import com.hchen.superlyric.data.LocalConfig;
import com.hchen.superlyric.utils.LyricCacheStore;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * SuperLyric 核心 Hook 入口。
 * <p>
 * 基于全新统一架构，直接按目标包名加载对应的 UnifiedLyricProvider 或系统代理，
 * 彻底消除 offline / online 路径割裂。
 *
 * @author 焕晨HChen
 */
public final class HookEntrance extends ReloadModuleEntrance {
    private static final String TAG = "SuperLyric";

    @Override
    public void initModuleConfig() {
        com.hchen.superlyric.reload.CallbackEndpoints.install(ModuleData.getWrapper());
        ModuleConfig.setLogTag(TAG);
        ModuleConfig.setPrefsName("super_lyric_prefs");
        ModuleConfig.setLogLevel(BuildConfig.DEBUG ? LOG_D : LocalConfig.getLogLevelForXposed());
        ModuleConfig.setShowHookSuccessLog(BuildConfig.DEBUG || LocalConfig.getLogLevelForXposed() == LOG_D);
        ModuleConfig.setLogExpandPaths(
            "com.hchen.superlyric.publisher",
            "com.hchen.superlyric.provider",
            "com.hchen.superlyric.core"
        );
        ModuleConfig.setLogExpandIgnoreClassNames(
            "com.hchen.superlyric.publisher.AbsPublisher"
        );
    }

    @NonNull
    @Override
    public String[] ignorePackages() {
        return new String[]{
            "com.miui.contentcatcher",
            "com.android.providers.settings",
            "com.android.server.telecom",
            "com.google.android.webview"
        };
    }

    private final HashMap<String, List<AbsModule>> modules = new HashMap<>();
    private final HashMap<String, PackageReadyParam> readyPackages = new HashMap<>();
    private ClassLoader systemLoader;
    private final HashMap<String, ClassLoader> moduleClassLoaders = new HashMap<>();
    private final ExecutorService cacheMigrationExecutor = Executors.newSingleThreadExecutor();
    @Nullable
    private Context lastApplicationContext;

    @Override
    public void handlePackageReady(@NonNull PackageReadyParam param) {
        if (ReloadResources.retiring) return;
        readyPackages.put(param.getPackageName(), param);
        AndroidLog.logD(TAG, "handlePackageReady: " + param.getPackageName() + " with loader: " + param.getClassLoader());
        super.handlePackageReady(param);

        if (HookMaps.ON_PACKAGE_LOADED.containsKey(param.getPackageName())) {
            try {
                int version = PrefsTool.prefs().getInt("super_lyric_dexkit_cache_version", 0);

                ModuleData.setClassLoader(param.getClassLoader());
                DexkitCache.init(
                    "superlyric",
                    param.getClassLoader(),
                    param.getApplicationInfo().sourceDir,
                    param.getApplicationInfo().dataDir,
                    version
                );

                ClassLoader previousLoader = moduleClassLoaders.get(param.getPackageName());
                if (modules.containsKey(param.getPackageName()) && previousLoader == param.getClassLoader()) {
                    for (AbsModule module : Objects.requireNonNull(modules.get(param.getPackageName()))) {
                        module.handlePackageReady(param);
                    }
                    return;
                }
                if (previousLoader != null && previousLoader != param.getClassLoader()) {
                    AndroidLog.logE(TAG, "Ignore package reload with different ClassLoader: " + param.getPackageName());
                    return;
                }

                List<AbsModule> packageModules = new ArrayList<>();
                for (String path : Objects.requireNonNull(HookMaps.ON_PACKAGE_LOADED.get(param.getPackageName()))) {
                    try {
                        AbsModule module = (AbsModule) HookEntrance.class.getClassLoader()
                            .loadClass(path)
                            .getDeclaredConstructor()
                            .newInstance();

                        module.handlePackageReady(param);
                        packageModules.add(module);
                    } catch (IllegalAccessException | InstantiationException |
                             InvocationTargetException | NoSuchMethodException |
                             ClassNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                }
                modules.put(param.getPackageName(), packageModules);
                moduleClassLoaders.put(param.getPackageName(), param.getClassLoader());
            } finally {
                DexkitCache.close();
            }
        }
    }

    @Override
    public void handleApplicationCreated(@NonNull Context context) {
        if (ReloadResources.retiring) return;
        AndroidLog.logD(TAG, "handleApplicationCreated: " + context.getPackageName());
        super.handleApplicationCreated(context);

        if (lastApplicationContext == context) return;
        cacheMigrationExecutor.execute(() -> clearLyricCacheOnFormatUpgrade(context));
        List<AbsModule> packageModules = modules.get(context.getPackageName());
        if (packageModules != null) {
            for (AbsModule module : packageModules) {
                module.handleApplicationCreated(context);
            }
        }
        lastApplicationContext = context;
    }

    private void clearLyricCacheOnFormatUpgrade(@NonNull Context context) {
        try {
            int lastCleared = PrefsTool.prefs(context).getInt("super_lyric_cache_format", 0);
            int current = LyricCacheStore.cacheVersion();
            if (lastCleared == current) return;
            if (!LyricCacheStore.clearOnlineProviderCaches(context)) {
                AndroidLog.logE(TAG, "Lyric cache format migration incomplete; retry on next startup");
                return;
            }
            boolean committed = PrefsTool.prefs(context)
                .edit()
                .putInt("super_lyric_cache_format", current)
                .commit();
            if (!committed) {
                AndroidLog.logE(TAG, "Failed to persist lyric cache format migration; retry on next startup");
                return;
            }
            AndroidLog.logD(TAG, "Lyric cache cleared on format upgrade: " + lastCleared + " -> " + current);
        } catch (Throwable t) {
            AndroidLog.logE(TAG, "Failed to clear lyric cache on format upgrade", t);
        }
    }

    @Override
    public void handleSystemServerStarting(@NonNull SystemServerStartingParam param) {
        super.handleSystemServerStarting(param);
        systemLoader = param.getClassLoader();

        ModuleData.setClassLoader(param.getClassLoader());
        for (List<String> value : HookMaps.ON_SYSTEM_STARTING.values()) {
            for (String path : value) {
                try {
                    AbsModule module = (AbsModule) HookEntrance.class.getClassLoader()
                        .loadClass(path)
                        .getDeclaredConstructor()
                        .newInstance();
                    module.handleSystemServerStarting(param);
                } catch (IllegalAccessException | InstantiationException |
                         InvocationTargetException | NoSuchMethodException |
                         ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    @Override
    public boolean isHotReloadingAllowed(@NonNull String packageName) {
        return !ReloadResources.retiring && android.os.Looper.myLooper() != android.os.Looper.getMainLooper();
    }

    @Override
    public Map<String, Object> handleHotReloading(@Nullable Bundle extras) {
        ReloadResources.retiring = true;
        Map<String, Object> saved = new HashMap<>();
        saved.put("context", lastApplicationContext);
        saved.put("systemLoader", systemLoader);
        Map<String, Object> packages = new HashMap<>();
        readyPackages.forEach((pkg, param) -> {
            Map<String, Object> item = new HashMap<>();
            item.put("info", param.getApplicationInfo());
            item.put("loader", param.getClassLoader());
            item.put("defaultLoader", param.getDefaultClassLoader());
            item.put("factory", param.getAppComponentFactory());
            item.put("first", param.isFirstPackage());
            packages.put(pkg, item);
        });
        saved.put("packages", packages);
        if (modules.containsKey("com.android.systemui")) LyriconBridge.close();
        Map<String, Object> providerStates = new HashMap<>();
        for (Map.Entry<String, List<AbsModule>> entry : modules.entrySet()) for (AbsModule module : entry.getValue()) {
            if (module instanceof UnifiedLyricProvider provider) {
                providerStates.put(entry.getKey() + "/" + module.getClass().getName(), provider.saveReloadState());
                provider.close();
            }
        }
        saved.put("providerStates", providerStates);
        saved.put("systemService", SuperLyricProxy.retireAndSave());
        ReloadResources.stop(cacheMigrationExecutor);
        modules.clear();
        moduleClassLoaders.clear();
        readyPackages.clear();
        lastApplicationContext = null;
        com.hchen.superlyric.reload.CallbackEndpoints.retire();
        ReloadResources.onMain(() -> null);
        com.hchen.superlyric.reload.ProviderWorkers.retire();
        com.hchen.superlyric.reload.LibraryWorkers.close();
        AndroidLog.logI(TAG, "Hot reload: old generation retired");
        return saved;
    }

    @Override
    public void handleHotReloadingFailed(@NonNull Throwable error) {
        SuperLyricProxy.failReload();
        AndroidLog.logE(TAG, "Hot reload retirement failed; process restart required", error);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void handleHotReloaded(@NonNull HotReloadedParam param, @NonNull ClassLoader loader) {
        Map<String, Object> saved = (Map<String, Object>) param.getSavedInstanceState();
        if (saved == null) throw new IllegalStateException("Missing hot reload state");
        ClassLoader system = (ClassLoader) saved.get("systemLoader");
        if (system != null) {
            SuperLyricProxy.prepareRestore((Map<String, Object>) saved.get("systemService"));
            handleSystemServerStarting(() -> system);
        }
        Map<String, Object> packages = (Map<String, Object>) saved.get("packages");
        if (packages != null) packages.forEach((pkg, value) -> {
            Map<String, Object> item = (Map<String, Object>) value;
            handlePackageReady(new PackageReadyParam() {
                public String getPackageName() { return pkg; }
                public ApplicationInfo getApplicationInfo() { return (ApplicationInfo) item.get("info"); }
                public boolean isFirstPackage() { return Boolean.TRUE.equals(item.get("first")); }
                public ClassLoader getClassLoader() { return (ClassLoader) item.get("loader"); }
                public ClassLoader getDefaultClassLoader() { return (ClassLoader) item.get("defaultLoader"); }
                public AppComponentFactory getAppComponentFactory() { return (AppComponentFactory) item.get("factory"); }
            });
        });
        Map<String, Object> providerStates = (Map<String, Object>) saved.get("providerStates");
        if (providerStates != null) {
            for (Map.Entry<String, List<AbsModule>> entry : modules.entrySet()) for (AbsModule module : entry.getValue()) {
                Object state = providerStates.get(entry.getKey() + "/" + module.getClass().getName());
                if (module instanceof UnifiedLyricProvider provider && state instanceof Bundle bundle) provider.restoreReloadState(bundle);
            }
        }
        Context context = (Context) saved.get("context");
        if (context != null) {
            ReloadResources.onMain(() -> { handleApplicationCreated(context); return null; });
            for (List<AbsModule> value : modules.values()) for (AbsModule module : value) {
                if (module instanceof UnifiedLyricProvider provider) provider.resumeAfterReload(context);
            }
        }
        AndroidLog.logI(TAG, "Hot reload complete: " + BuildConfig.VERSION_NAME + " / " + param.getProcessName());
    }
}
